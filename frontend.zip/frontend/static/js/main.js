// static/js/main.js

document.addEventListener('DOMContentLoaded', () => {
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('pdf_file');
    const fileNameDisplay = document.getElementById('file-name-display');
    const submitBtn = document.getElementById('submit-btn');
    const uploadForm = document.getElementById('upload-form');
    const processingOverlay = document.getElementById('processing-overlay');
    const progressBar = document.getElementById('progress-bar');
    const progressText = document.getElementById('progress-text');

    if (!dropZone) return; // Stop if not on the index page

    // 1. Handle File Input and Button State
    const updateFileStatus = (file) => {
        if (file) {
            fileNameDisplay.textContent = `Selected: ${file.name}`;
            submitBtn.disabled = false;
        } else {
            fileNameDisplay.textContent = 'No file selected';
            submitBtn.disabled = true;
        }
    };

    fileInput.addEventListener('change', (e) => {
        updateFileStatus(e.target.files[0]);
    });

    // Clicks on the drop zone open the file dialog
    dropZone.addEventListener('click', () => fileInput.click());

    // 2. Drag and Drop Functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, preventDefaults, false);
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    ['dragenter', 'dragover'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.add('dragover'), false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropZone.addEventListener(eventName, () => dropZone.classList.remove('dragover'), false);
    });

    dropZone.addEventListener('drop', handleDrop, false);

    function handleDrop(e) {
        let dt = e.dataTransfer;
        let files = dt.files;

        // Filter for the first PDF file
        let pdfFile = Array.from(files).find(file => file.type === 'application/pdf');

        if (pdfFile) {
            // Assign the file to the input element
            fileInput.files = dt.files;
            updateFileStatus(pdfFile);
        } else {
            alert("Only PDF files are supported.");
            updateFileStatus(null);
        }
    }

    // 3. Form Submission and Animated Loading
    let progressInterval;
    let progressStages = [
        "Uploading file...",
        "Validating document format...",
        "Performing OCR (Text Extraction)...",
        "Generating document summary...",
        "Detecting hidden contractual risks...",
        "Finalizing analysis report..."
    ];
    let currentStage = 0;

    const startFakeProgress = () => {
        processingOverlay.classList.add('visible');
        progressBar.style.width = '10%'; // Start at a low percentage
        progressText.textContent = progressStages[0];

        const totalDuration = 18000; // Total fake duration in ms (18 seconds)
        const stageDuration = totalDuration / progressStages.length;

        progressInterval = setInterval(() => {
            if (currentStage < progressStages.length) {
                currentStage++;
                // Update text and progress bar roughly
                if (currentStage < progressStages.length) {
                    progressText.textContent = progressStages[currentStage];
                    let newWidth = (currentStage / progressStages.length) * 80 + 10; // Max 90%
                    progressBar.style.width = `${newWidth}%`;
                }
            } else {
                // Keep it at 95% while waiting for the actual response
                progressBar.style.width = '95%';
                progressText.textContent = "Awaiting server response...";
            }
        }, stageDuration * 0.9);
    };

    uploadForm.addEventListener('submit', (e) => {
        // Only run if a file is selected and the button is enabled
        if (fileInput.files.length > 0) {
            startFakeProgress();
        }
    });

    // Clear interval when the page unloads (e.g., redirect happens)
    window.addEventListener('beforeunload', () => {
        if (progressInterval) {
            clearInterval(progressInterval);
        }
    });
});